import { dataPath } from "./data-dir.js";
import { readFile, writeFile, rename, mkdir, stat } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { PermissionFlagsBits } from "discord.js";
import { isSysPlus } from "./systems/sysplus/permissions.js";
import { isWhitelistMember } from "./systems/sysplus/whitelist-policy.js";
import { recordSysPlusAudit } from "./systems/sysplus/audit.js";
import { db } from "./database.js";
import { evaluateTargetHierarchy } from "./target-hierarchy-policy.js";
import { parsePndOwnerId } from "./pnd-owner-policy.js";
import { systemLogEmbed, sendCentralLog } from "./logs.js";
import {
  canCreateLeash,
  findLeashRole,
  isLeashRoleName,
  isOwnerLeashRoleName,
  leashRoleName,
  leashQuotaStatus,
  resolveMaxActiveLeashes,
} from "./dog-policy.js";

const stateFile = process.env.PND_DOG_STATE_PATH
  ? resolve(process.env.PND_DOG_STATE_PATH)
  : dataPath("dog-state.json");
const stateTempFile = process.env.PND_DOG_STATE_PATH
  ? `${stateFile}.tmp`
  : dataPath("dog-state.tmp");
let state;
let pendingWrite = Promise.resolve();
const enforcingMembers = new Map();
const enforcingVoiceMembers = new Map();
const leashRolePromises = new Map();
const commandLocks = new Map();

/**
 * Rôle « En laisse (Pseudo du maître) » : un seul par maître, partagé par ses laisses.
 * Cherché d'abord via les laisses actives de ce maître (le pseudo a pu changer : le rôle
 * est alors renommé), puis par son nom, sinon créé (création sérialisée par maître).
 */
async function getLeashRole(guild, ownerId, ownerName, records = null) {
  const botMember = await guild.members.fetchMe();
  if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
    throw new Error("Le bot doit avoir la permission Gérer les rôles pour protéger la laisse DOG.");
  }
  const expectedName = leashRoleName(ownerName);
  let role = null;
  for (const record of Object.values(records ?? {})) {
    if (record?.guildId !== guild.id || record.ownerId !== ownerId || record.releasing || !record.leashRoleId) continue;
    const candidate = await fetchRole(guild, record.leashRoleId);
    if (candidate && isOwnerLeashRoleName(candidate.name)) { role = candidate; break; }
  }
  role ??= findLeashRole(guild.roles.cache, botMember.roles.highest.position, ownerName);
  // Retrouvé par son nom : on ne réutilise qu'un rôle sans AUCUNE permission, sinon un rôle
  // nommé « En laisse (…) » à la main pourrait être donné au membre tenu en laisse.
  if (role && !leashRoleIsHarmless(role)) role = null;
  if (!role) {
    const key = `${guild.id}:${ownerId}`;
    if (!leashRolePromises.has(key)) {
      const pending = guild.roles
        .create({
          name: expectedName,
          color: 0x8b5cf6,
          permissions: [],
          mentionable: false,
          hoist: false,
          reason: `Rôle système DOG — laisse de ${String(ownerName ?? ownerId).slice(0, 60)}`,
        })
        .finally(() => {
          leashRolePromises.delete(key);
        });
      leashRolePromises.set(key, pending);
    }
    role = await leashRolePromises.get(key);
  }
  if (role.position >= botMember.roles.highest.position) {
    throw new Error("Le rôle DOG doit être placé sous le rôle le plus élevé du bot.");
  }
  if (role.name !== expectedName && typeof role.setName === "function") {
    role = await role.setName(expectedName, "DOG : pseudo du maître mis à jour").catch(() => role);
  }
  return role;
}

function leashRoleIsHarmless(role) {
  if (!role || role.managed) return false;
  try { return BigInt(role.permissions?.bitfield ?? role.permissions ?? 0) === 0n; } catch { return false; }
}

async function fetchRole(guild, roleId) {
  if (!roleId) return null;
  const cached = guild.roles?.cache?.get?.(roleId);
  if (cached) return cached;
  try { return (await guild.roles?.fetch?.(roleId)) ?? null; } catch { return null; }
}

/** Supprime un rôle « En laisse (…) » que plus personne ne porte et qu'aucune laisse n'utilise. */
async function releaseLeashRoleIfUnused(guild, roleId, records) {
  if (!guild || !roleId) return false;
  if (Object.values(records ?? {}).some((record) => record?.guildId === guild.id && record.leashRoleId === roleId && !record.releasing)) return false;
  const role = await fetchRole(guild, roleId);
  if (!role || role.managed || !isOwnerLeashRoleName(role.name)) return false;
  if ((role.members?.size ?? 0) > 0) return false;
  return Boolean(await role.delete("DOG : plus aucune laisse pour ce maître").catch(() => null));
}

// Fingerprint of the file as last read. The modification time alone is not
// enough: on a fast machine two writes can land within the same clock tick and
// keep the same mtime, so size and inode (an atomic rename gives a new one) count too.
let stateMtimeMs = null;
async function fileMtime() {
  try {
    const info = await stat(stateFile);
    return `${info.mtimeMs}:${info.size}:${info.ino}`;
  } catch (error) { if (error.code === "ENOENT") return null; throw error; }
}

// Several FWU bots share this file (shared data folder): reload it when another
// process changed it, so every bot sees the same leashes.
async function loadState() {
  const mtime = await fileMtime();
  if (state && mtime === stateMtimeMs) return state;
  try {
    state = JSON.parse(await readFile(stateFile, "utf8"));
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    state = {};
  }
  stateMtimeMs = mtime;
  return state;
}

async function saveState() {
  const snapshot = JSON.stringify(state, null, 2);
  const write = pendingWrite.catch(() => {}).then(async () => {
    await mkdir(dirname(stateFile), { recursive: true, mode: 0o700 });
    await writeFile(stateTempFile, snapshot, { mode: 0o600 });
    await rename(stateTempFile, stateFile);
    stateMtimeMs = await fileMtime();
  });
  pendingWrite = write;
  await write;
}

function key(guildId, memberId) {
  return `${guildId}:${memberId}`;
}

function dogNickname(ownerName) {
  // Discord limits nicknames to 32 characters.
  return `🦮 de ${ownerName}`.slice(0, 32);
}

async function withCommandLock(lockKey, action) {
  const previous = commandLocks.get(lockKey) ?? Promise.resolve();
  let release;
  const current = new Promise((resolve) => { release = resolve; });
  commandLocks.set(lockKey, current);
  await previous.catch(() => {});
  try { return await action(); }
  finally {
    release();
    if (commandLocks.get(lockKey) === current) commandLocks.delete(lockKey);
  }
}

export async function isMemberDogged(guildId, memberId) {
  if (!guildId || !memberId) return false;
  const records = await loadState();
  const record = records[key(guildId, memberId)];
  return Boolean(record && !record.releasing);
}

// Anti-conflit : si deux bots (ou une ancienne version du bot, ex. pseudo « 🐶 de … » et
// rôle commun « En laisse ») imposent chacun « leur » laisse, ils se la renvoient sans fin.
// Au-delà de LEASH_RESTORE_MAX rétablissements par minute pour un membre, le maintien est
// suspendu LEASH_RESTORE_PAUSE_MS pour ce membre, puis =dogfix le remet d'aplomb.
const LEASH_RESTORE_MAX = 4;
const LEASH_RESTORE_WINDOW_MS = 60_000;
const LEASH_RESTORE_PAUSE_MS = 5 * 60_000;
const leashRestoreHistory = new Map();
const leashRestorePaused = new Map();
const leashConflicts = new Map();

/** Tests only: reset the anti-conflict counters. */
export function resetLeashRestoreGuardForTests() {
  leashRestoreHistory.clear();
  leashRestorePaused.clear();
  leashConflicts.clear();
}

function clearLeashRestoreGuard(id) {
  leashRestoreHistory.delete(id);
  leashRestorePaused.delete(id);
}

/** "ok" (restore allowed and counted), "paused" (still suspended) or "tripped" (just suspended). */
function takeLeashRestore(id, now = Date.now()) {
  const until = leashRestorePaused.get(id);
  if (until && until > now) return "paused";
  if (until) leashRestorePaused.delete(id);
  const recent = (leashRestoreHistory.get(id) ?? []).filter((at) => now - at < LEASH_RESTORE_WINDOW_MS);
  if (recent.length >= LEASH_RESTORE_MAX) {
    leashRestoreHistory.delete(id);
    leashRestorePaused.set(id, now + LEASH_RESTORE_PAUSE_MS);
    leashConflicts.set(id, now);
    return "tripped";
  }
  recent.push(now);
  leashRestoreHistory.set(id, recent);
  if (leashRestoreHistory.size > 5_000) {
    for (const [entry, times] of leashRestoreHistory) if (!times.some((at) => now - at < LEASH_RESTORE_WINDOW_MS)) leashRestoreHistory.delete(entry);
  }
  if (leashConflicts.size > 5_000) {
    for (const [entry, at] of leashConflicts) if (now - at > 24 * 60 * 60_000) leashConflicts.delete(entry);
  }
  return "ok";
}

/** Leash roles a member carries besides the current one (old shared role, another owner's role…). */
function strayLeashRoles(member, keepRoleId) {
  const cache = member?.roles?.cache;
  if (typeof cache?.values !== "function") return [];
  return [...cache.values()].filter((role) => role?.id !== keepRoleId && !role.managed && isLeashRoleName(role.name));
}

/** Reapply the persistent leash role and nickname after any member update. */
export async function enforceLeashNickname(member, options = {}) {
  if (!member?.guild || !member.id) return false;
  const id = key(member.guild.id, member.id);
  if ((leashRestorePaused.get(id) ?? 0) > Date.now()) return false;
  const activeEnforcement = enforcingMembers.get(id);
  if (activeEnforcement) {
    activeEnforcement.latestMember = member;
    activeEnforcement.rerun = true;
    return false;
  }

  const run = { latestMember: member, rerun: false };
  enforcingMembers.set(id, run);
  let restored = false;

  try {
    do {
      run.rerun = false;
      const eventMember = run.latestMember;
      const record = (await loadState())[id];
      if (!record || record.releasing) return restored;

      // Fetch current state instead of trusting a possibly stale event snapshot.
      const currentMember = await eventMember.guild.members.fetch(eventMember.id).catch(() => eventMember);

      let leashRole = record.leashRoleId
        ? (currentMember.guild.roles.cache.get(record.leashRoleId)
          ?? await currentMember.guild.roles.fetch(record.leashRoleId).catch(() => null))
        : null;
      // Absent, ou ancien rôle commun « En laisse » : passage au rôle « En laisse (Maître) ».
      if (!leashRole || !isOwnerLeashRoleName(leashRole.name)) {
        const previousRole = leashRole;
        leashRole = await getLeashRole(currentMember.guild, record.ownerId, record.ownerName, await loadState());
        record.leashRoleId = leashRole.id;
        await saveState();
        if (previousRole && previousRole.id !== leashRole.id && currentMember.roles.cache.has(previousRole.id)) {
          await currentMember.roles.remove(previousRole, "DOG : passage au rôle du maître").catch(() => {});
        }
      }
      const expectedNickname = dogNickname(record.ownerName || "son propriétaire");
      const stray = strayLeashRoles(currentMember, leashRole.id);
      const needsWork = stray.length > 0
        || !currentMember.roles.cache.has(leashRole.id)
        || currentMember.nickname !== expectedNickname;
      if (!needsWork) continue;
      const allowance = takeLeashRestore(id);
      if (allowance !== "ok") {
        if (allowance === "tripped") options.onConflict?.(record);
        return restored;
      }

      for (const role of stray) {
        await currentMember.roles.remove(role, "DOG : ancienne laisse retirée").catch(() => {});
        restored = true;
      }
      if (!currentMember.roles.cache.has(leashRole.id)) {
        const botMember = await currentMember.guild.members.fetchMe();
        if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles) || leashRole.position >= botMember.roles.highest.position) {
          throw new Error("Le rôle DOG n'est pas gérable dans la hiérarchie Discord.");
        }
        await currentMember.roles.add(leashRole, "DOG : maintien du rôle de laisse");
        restored = true;
      }

      if (currentMember.nickname === expectedNickname) continue;

      const botMember = await currentMember.guild.members.fetchMe();
      if (!botMember.permissions.has(PermissionFlagsBits.ManageNicknames)) return restored;
      if (currentMember.id === currentMember.guild.ownerId || currentMember.roles.highest.position >= botMember.roles.highest.position) return restored;

      try {
        await currentMember.setNickname(expectedNickname, "DOG : rétablissement du surnom de laisse");
        restored = true;
      } catch {
        // The marker role still keeps the leash active if nickname editing is unavailable.
      }
    } while (run.rerun);

    return restored;
  } finally {
    enforcingMembers.delete(id);
  }
}

/** Restore active DOG nicknames after the bot reconnects. */
export async function reconcileLeashedMembers(client) {
  const records = await loadState();
  let restored = 0;
  for (const record of Object.values(records)) {
    if (!record || record.releasing || !record.guildId || !record.memberId) continue;
    const guild = client.guilds.cache.get(record.guildId);
    if (!guild) continue;
    const member = await guild.members.fetch(record.memberId).catch(() => null);
    if (member && await enforceLeashNickname(member)) restored++;
    if (member && await enforceLeashVoice(guild, record.memberId)) restored++;
  }
  return restored;
}

// Anti-boucle : au plus LEASH_FOLLOW_MAX déplacements par minute et par membre
// (un autre bot ou un modérateur qui la remet sans cesse ailleurs, rate limits Discord).
const LEASH_FOLLOW_MAX = 6;
const LEASH_FOLLOW_WINDOW_MS = 60_000;
const leashFollowHistory = new Map();

/** Tests only: reset the anti-loop counters. */
export function forgetLeashFollowHistory() {
  leashFollowHistory.clear();
  pendingLeashRetries?.clear?.();
}

function takeLeashFollowSlot(id, now = Date.now()) {
  const recent = (leashFollowHistory.get(id) ?? []).filter((at) => now - at < LEASH_FOLLOW_WINDOW_MS);
  if (recent.length >= LEASH_FOLLOW_MAX) {
    leashFollowHistory.set(id, recent);
    return false;
  }
  recent.push(now);
  leashFollowHistory.set(id, recent);
  if (leashFollowHistory.size > 5_000) {
    for (const [entry, times] of leashFollowHistory) if (!times.some((at) => now - at < LEASH_FOLLOW_WINDOW_MS)) leashFollowHistory.delete(entry);
  }
  return true;
}

/**
 * Move a connected leashed member to their owner's current voice channel.
 * Only the BOT needs Move Members (source) and View + Connect (destination):
 * Discord lets a mover place a member in a locked or full channel, so the
 * leashed member's own Connect permission is deliberately not required.
 * Never throws: a refused or failed move returns false.
 */
const pendingLeashRetries = new Map();
const TRANSIENT_MOVE_CODES = new Set([429, 500, 502, 503, 504]);

function oldestFollowAge(id, now = Date.now()) {
  const recent = (leashFollowHistory.get(id) ?? []).filter((at) => now - at < LEASH_FOLLOW_WINDOW_MS);
  return recent.length ? now - Math.min(...recent) : LEASH_FOLLOW_WINDOW_MS;
}

/**
 * Remet la personne en laisse dans le vocal de son maître.
 * V2 (correction du suivi) :
 *  • permission « Déplacer des membres » vérifiée aussi sur le salon du maître ;
 *  • erreur passagère de Discord (limite de débit, 5xx) → un nouvel essai ;
 *  • limite anti-boucle atteinte → un nouvel essai programmé à la fin de la fenêtre
 *    (avant : la personne restait derrière jusqu'au prochain mouvement du maître) ;
 *  • toute cause d'échec est signalée (`onBlocked`).
 */
export async function enforceLeashVoice(guild, memberId, { schedule = (fn, ms) => setTimeout(fn, ms).unref?.(), retryDelayMs = 1_500, onBlocked = () => {} } = {}) {
  if (!guild || !memberId) return false;
  const id = key(guild.id, memberId);
  const activeRun = enforcingVoiceMembers.get(id);
  if (activeRun) {
    activeRun.rerun = true;
    return false;
  }

  const run = { rerun: false };
  enforcingVoiceMembers.set(id, run);
  let moved = false;
  const blocked = (reason) => { try { onBlocked(reason); } catch { /* signalement seulement */ } };

  try {
    do {
      run.rerun = false;
      const record = (await loadState())[id];
      if (!record || record.releasing || !record.ownerId || record.ownerId === memberId) return moved;

      const target = guild.members.cache.get(memberId) ?? await guild.members.fetch(memberId).catch(() => null);
      const owner = guild.members.cache.get(record.ownerId) ?? await guild.members.fetch(record.ownerId).catch(() => null);
      const targetChannel = target?.voice.channel;
      const ownerChannel = owner?.voice.channel;
      // Cible ou maître hors vocal, ou déjà ensemble : rien à faire.
      if (!target || !targetChannel || !ownerChannel || targetChannel.id === ownerChannel.id) continue;

      const botMember = await guild.members.fetchMe().catch(() => null);
      if (!botMember) return moved;
      const sourcePermissions = targetChannel.permissionsFor(botMember);
      const destinationPermissions = ownerChannel.permissionsFor(botMember);
      if (!sourcePermissions?.has(PermissionFlagsBits.MoveMembers) ||
          !destinationPermissions?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.MoveMembers])) {
        blocked("permission");
        return moved;
      }
      if (!takeLeashFollowSlot(id)) {
        blocked("rate_limited");
        if (!pendingLeashRetries.has(id)) {
          const delay = Math.max(1_000, LEASH_FOLLOW_WINDOW_MS - oldestFollowAge(id) + 250);
          pendingLeashRetries.set(id, true);
          schedule(async () => {
            pendingLeashRetries.delete(id);
            await enforceLeashVoice(guild, memberId, { schedule, retryDelayMs, onBlocked }).catch(() => false);
          }, delay);
        }
        return moved;
      }

      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          await target.voice.setChannel(ownerChannel, "DOG : retour dans le vocal du propriétaire");
          moved = true;
          break;
        } catch (error) {
          const status = Number(error?.status ?? error?.httpStatus ?? 0);
          const transient = TRANSIENT_MOVE_CODES.has(status) || (!error?.code && !status);
          if (attempt === 0 && transient) {
            await new Promise((resolve) => setTimeout(resolve, retryDelayMs));
            continue;
          }
          blocked(Number(error?.code) === 50013 ? "permission" : "discord_error");
          return moved; // permissions retirées, membre parti… : on n'insiste pas
        }
      }
    } while (run.rerun);

    return moved;
  } finally {
    enforcingVoiceMembers.delete(id);
  }
}

/** Enforce the voice leash when either the leashed member or their owner moves. */
export async function handleLeashVoiceState(oldState, newState, options = {}) {
  if (oldState.channelId === newState.channelId) return 0;
  const guild = newState.guild;
  if (!guild) return 0;
  const records = await loadState();
  const changedMemberId = newState.id;
  const targets = [];
  if (records[key(guild.id, changedMemberId)] && !records[key(guild.id, changedMemberId)].releasing) {
    targets.push(changedMemberId);
  }
  for (const record of Object.values(records)) {
    if (record?.guildId === guild.id && record.ownerId === changedMemberId && !record.releasing) {
      targets.push(record.memberId);
    }
  }

  let moved = 0;
  for (const targetId of new Set(targets)) {
    if (await enforceLeashVoice(guild, targetId, options)) moved++;
  }
  return moved;
}

/**
 * Puts one member on a leash. The caller holds the guild's dog-state lock and has checked
 * the hierarchy. Returns { ok, text } and never replies itself (used by =dog and =dogall).
 */
async function leashMember({ guild, actor, author, target, guildSettings }) {
  const id = key(guild.id, target.id);
  const freshRecords = await loadState();
  const freshExisting = freshRecords[id];
  if (freshExisting && !freshExisting.releasing) {
    return { ok: false, already: true, text: `🦮 Ce membre est déjà en laisse par **${freshExisting.ownerName}**. Utilise \`=undog @membre\` pour retirer la laisse.` };
  }
  const whitelisted = isWhitelistMember(actor, guildSettings?.sysPlus?.whitelistRoleId ?? null);
  // Per-guild limit from /setup (dog.maxActiveLeashes); historical default 3 when unset.
  const maxLeashes = resolveMaxActiveLeashes(guildSettings?.dog?.maxActiveLeashes);
  const quota = leashQuotaStatus(freshRecords, guild.id, author.id, maxLeashes, whitelisted);
  const activeCount = quota.activeCount;
  if (!canCreateLeash(freshRecords, guild.id, author.id, maxLeashes, whitelisted)) {
    return { ok: false, quota: true, text: `⛔ Tu as déjà **${activeCount}/${maxLeashes}** laisses actives. Libère-en une avec \`=undog @membre\` avant d'en ajouter une autre.` };
  }
  const menotte = db.prepare("SELECT channel_id FROM voice_menottes WHERE guild_id=? AND member_id=?").get(guild.id, target.id);
  if (menotte) return { ok: false, text: "⛔ Ce membre est déjà soumis au système MENOTTE. Libère d'abord cette restriction." };
  const nicknameLock = db.prepare("SELECT 1 FROM protected_nicknames WHERE guild_id=? AND member_id=?").get(guild.id, target.id);
  if (nicknameLock) return { ok: false, text: "⛔ Retire d’abord LOCKNAME avant de modifier le pseudonyme avec DOG." };

  const previousNickname = target.nickname;
  const ownerName = actor.displayName || author.username;
  let leashRole;
  try {
    leashRole = await getLeashRole(guild, author.id, ownerName, freshRecords);
  } catch (error) {
    return { ok: false, text: `❌ ${error.message} Vérifie les permissions et la position des rôles du bot.` };
  }
  freshRecords[id] = {
    guildId: guild.id,
    memberId: target.id,
    previousNickname,
    ownerId: author.id,
    ownerName,
    leashRoleId: leashRole.id,
    since: Date.now(),
  };
  try {
    await saveState();
    await target.roles.add(leashRole, `Mis en laisse par ${author.tag}`);
    await target.setNickname(dogNickname(ownerName), `Mis en laisse par ${author.tag}`);
  } catch (error) {
    delete freshRecords[id];
    await saveState().catch(() => {});
    await target.roles.remove(leashRole, "Annulation de la laisse DOG échouée").catch(() => {});
    await releaseLeashRoleIfUnused(guild, leashRole.id, freshRecords).catch(() => {});
    console.error("DOG command failed:", error.message);
    return { ok: false, text: "❌ Impossible de mettre ce membre en laisse. Vérifie la hiérarchie des rôles et mes permissions." };
  }
  const returnedToOwner = await enforceLeashVoice(guild, target.id).catch(() => false);
  const leashCount = quota.label;
  if (quota.exceptionUsed) {
    try {
      recordSysPlusAudit(guild.id, author.id, "dog.whitelist_quota_exception", target.id, {
        activeBefore: activeCount,
        configuredLimit: maxLeashes,
      });
    } catch (error) {
      console.error("DOG whitelist exception audit failed:", error.message);
    }
  }
  await sendCentralLog(guild, guildSettings, systemLogEmbed({ category: "dog", title: "🦮 DOG — laisse attribuée", description: `Acteur : <@${author.id}>\nCible : <@${target.id}>\nLaisses actives : ${leashCount}` })).catch(() => {});
  return {
    ok: true,
    text: `🦮 **${target.user.username}** est maintenant en laisse par **${ownerName}** (${leashCount}).${returnedToOwner ? " Il a été ramené dans ton salon vocal." : ""}`,
  };
}

/**
 * =dogall / /dogall (SYS+): leash every member of the actor's voice channel, but only when
 * they all fit in the actor's remaining leashes — otherwise nothing is done. Each member
 * goes through the same hierarchy and protection checks as =dog; refused ones are listed.
 */
async function handleDogAll(message, actor, guildSettings) {
  const reply = (content) => message.reply({ content, allowedMentions: { parse: [] } });
  const channel = actor.voice?.channel;
  if (!channel) return reply("🎧 Rejoins d'abord un salon vocal : /dogall met en laisse les membres de ton salon.").then(() => true);
  const botMember = await message.guild.members.fetchMe();
  if (!botMember.permissions.has(PermissionFlagsBits.ManageNicknames)) return reply("❌ Il me manque la permission **Gérer les surnoms**.").then(() => true);
  return withCommandLock(`${message.guild.id}:dog-state`, async () => {
    await pruneDepartedLeashes(message.guild);
    const records = await loadState();
    const present = [...channel.members.values()].filter((member) => member.id !== actor.id && !member.user.bot);
    const candidates = present.filter((member) => {
      const record = records[key(message.guild.id, member.id)];
      return !record || record.releasing;
    });
    if (!candidates.length) {
      await reply(present.length ? "🐾 Tout le monde dans ton salon est déjà en laisse." : "🐾 Personne d'autre que toi dans ce salon.");
      return true;
    }
    const remaining = await remainingLeashes(message.guild, actor, message.author.id, guildSettings);
    if (candidates.length > remaining) {
      await reply(`⛔ ${candidates.length} membres à mettre en laisse, mais il ne te reste que **${remaining}** laisse(s). Rien n'a été fait.`);
      return true;
    }
    const pndOwnerId = parsePndOwnerId(process.env.PND_OWNER_DISCORD_ID);
    const done = [];
    const skipped = [];
    for (const target of candidates) {
      const hierarchy = evaluateTargetHierarchy({ actor, target, bot: botMember, guildOwnerId: message.guild.ownerId, pndOwnerId, enforceActorRank: true, allowSelf: false });
      if (!hierarchy.allowed) { skipped.push(`<@${target.id}> (${String(hierarchy.reason).slice(0, 80)})`); continue; }
      const result = await leashMember({ guild: message.guild, actor, author: message.author, target, guildSettings });
      if (result.ok) done.push(`<@${target.id}>`);
      else skipped.push(`<@${target.id}> (${result.text.replace(/^\S+\s/, "").slice(0, 80)})`);
    }
    const lines = [`🦮 **${done.length}** membre(s) de <#${channel.id}> mis en laisse.`];
    if (done.length) lines.push(done.join(", "));
    if (skipped.length) lines.push(`Non mis en laisse : ${skipped.join(" ; ")}`);
    await reply(lines.join("\n").slice(0, 1900));
    return true;
  });
}

/** Remaining leashes an actor may still create (Infinity for WHITELIST, which only lifts this internal limit). */
async function remainingLeashes(guild, actor, authorId, guildSettings) {
  const records = await loadState();
  const whitelisted = isWhitelistMember(actor, guildSettings?.sysPlus?.whitelistRoleId ?? null);
  if (whitelisted) return Infinity;
  const maxLeashes = resolveMaxActiveLeashes(guildSettings?.dog?.maxActiveLeashes);
  const { activeCount } = leashQuotaStatus(records, guild.id, authorId, maxLeashes, false);
  return Math.max(0, maxLeashes - activeCount);
}

function conflictWarning(conflicts = []) {
  if (!conflicts.length) return "";
  const last = Math.floor(Math.max(...conflicts) / 1000);
  return `\n⚠️ Conflit détecté (${conflicts.length} membre(s), dernier <t:${last}:R>) : un autre bot remettait une autre laisse. Une ancienne version d'un bot tourne probablement encore en parallèle.`;
}

/**
 * =dogfix @membre : relit l'état sur disque, lève la suspension anti-conflit, retire les
 * anciens rôles de laisse et réapplique la laisse enregistrée. Sans laisse enregistrée (ou
 * laisse bloquée en cours de retrait), nettoie les restes : rôle DOG et pseudo « 🦮/🐶 de … ».
 */
export async function repairMemberLeash(target, actorTag = "bot") {
  const id = key(target.guild.id, target.id);
  stateMtimeMs = null; // force a fresh read: another process may have changed the file
  const records = await loadState();
  const record = records[id];
  const conflictAt = leashConflicts.get(id);
  leashConflicts.delete(id);
  clearLeashRestoreGuard(id);
  const conflicts = conflictAt ? [conflictAt] : [];
  const name = target.user?.username ?? target.displayName ?? target.id;

  if (!record || record.releasing) {
    if (record?.releasing) {
      delete records[id];
      await saveState();
    }
    let cleaned;
    try { cleaned = await clearOrphanLeash(target, actorTag); } catch { cleaned = null; }
    if (cleaned === null) return { conflicts, text: `❌ Impossible de nettoyer **${name}** : mon rôle doit être au-dessus du rôle DOG et de ce membre.` };
    if (cleaned || record?.releasing) return { conflicts, text: `🔧 **${name}** n'a plus de laisse enregistrée : restes d'ancienne laisse retirés (rôle DOG et pseudo).` };
    return { conflicts, text: `✅ **${name}** n'est pas en laisse et ne porte aucun reste de laisse : rien à réparer.` };
  }

  try {
    const changed = await enforceLeashNickname(target);
    const fresh = await target.guild.members.fetch(target.id).catch(() => target);
    const role = await fetchRole(target.guild, records[id]?.leashRoleId ?? record.leashRoleId);
    const expected = dogNickname(record.ownerName || "son propriétaire");
    const nicknameOk = fresh.nickname === expected;
    const details = `rôle « ${role?.name ?? "En laisse"} »${nicknameOk ? ` et pseudo « ${expected} »` : " (pseudo non modifiable : hiérarchie ou permission Gérer les surnoms)"}`;
    return {
      conflicts,
      text: changed
        ? `🔧 Laisse de **${name}** remise d'aplomb : ${details}.`
        : `✅ La laisse de **${name}** est correcte : ${details}. Rien à réparer.`,
    };
  } catch (error) {
    return { conflicts, text: `❌ Impossible de réparer la laisse de **${name}** : ${error.message}` };
  }
}

/** =dogfix sans membre : même réparation pour toutes les laisses actives du serveur. */
export async function repairGuildLeashes(guild) {
  await pruneDepartedLeashes(guild).catch(() => 0);
  stateMtimeMs = null;
  const records = await loadState();
  const result = { checked: 0, repaired: 0, conflicts: [] };
  for (const record of Object.values(records)) {
    if (!record || record.releasing || record.guildId !== guild.id || !record.memberId) continue;
    const id = key(guild.id, record.memberId);
    const conflictAt = leashConflicts.get(id);
    if (conflictAt) result.conflicts.push(conflictAt);
    leashConflicts.delete(id);
    clearLeashRestoreGuard(id);
    const member = await guild.members.fetch(record.memberId).catch(() => null);
    if (!member) continue;
    result.checked += 1;
    if (await enforceLeashNickname(member).catch(() => false)) result.repaired += 1;
  }
  return result;
}

export async function handleDogCommand(message, guildSettings = null) {
  const parts = message.content.trim().split(/\s+/);
  const command = parts[0]?.toLowerCase();
  if (!["=dog", "=undog", "=doginfo", "=doglist", "=dogall", "=dogfix"].includes(command)) return false;

  if (!message.guild || !message.member) return true;
  const actor = await message.guild.members.fetch(message.author.id).catch(() => null);
  if (!actor || !isSysPlus(actor, guildSettings?.sysPlus?.roleId ?? null)) {
    await message.reply({
      content: "⛔ Cette commande est réservée aux membres SYS+.",
      allowedMentions: { parse: [] },
    });
    return true;
  }

  if (command === "=doglist") {
    const active = Object.values(await loadState())
      .filter((record) => record?.guildId === message.guild.id && record.memberId && !record.releasing)
      .sort((a, b) => Number(a.since || 0) - Number(b.since || 0));
    const lines = active.slice(0, 20).map((record, index) =>
      `${index + 1}. <@${record.memberId}> · par **${String(record.ownerName || "SYS+").slice(0, 64)}** · depuis <t:${Math.floor(Number(record.since || 0) / 1000)}:R>`,
    );
    await message.reply({
      content: `🐾 **Laisses actives · ${message.guild.name}** (${active.length})\n${lines.length ? lines.join("\n") : "Aucune laisse active."}${active.length > lines.length ? `\n… et ${active.length - lines.length} autre(s).` : ""}`,
      allowedMentions: { parse: [] },
    });
    return true;
  }

  if (command === "=dogall") return handleDogAll(message, actor, guildSettings);

  if (command === "=dogfix" && !message.mentions.members.first() && !parts[1]?.match(/^<@!?(\d+)>$/)) {
    const result = await repairGuildLeashes(message.guild);
    await message.reply({
      content: `🔧 **Réparation DOG · ${message.guild.name}** : ${result.checked} laisse(s) vérifiée(s), ${result.repaired} remise(s) d'aplomb.${conflictWarning(result.conflicts)}` ,
      allowedMentions: { parse: [] },
    });
    return true;
  }
  const targetId = message.mentions.members.first()?.id ?? parts[1]?.match(/^<@!?(\d+)>$/)?.[1];
  if (!targetId) {
    await message.reply({
      content: `Utilisation : \`${command} @membre\``,
      allowedMentions: { parse: [] },
    });
    return true;
  }

  const target = await message.guild.members.fetch(targetId).catch(() => null);
  if (!target) {
    // A leash on someone who left the server can always be cleared (nothing to restore on Discord).
    const records = await loadState();
    if (command === "=undog" && records[key(message.guild.id, targetId)]) {
      delete records[key(message.guild.id, targetId)];
      await saveState();
      await message.reply({ content: "🦴 Laisse supprimée : ce membre n'est plus sur le serveur.", allowedMentions: { parse: [] } });
      return true;
    }
    await message.reply({ content: "❌ Je ne trouve pas ce membre sur le serveur.", allowedMentions: { parse: [] } });
    return true;
  }

  if (target.id === message.author.id && command !== "=doginfo") {
    await message.reply({ content: "Tu ne peux pas appliquer cette action sur toi-même.", allowedMentions: { parse: [] } });
    return true;
  }

  const botMember = await message.guild.members.fetchMe();
  if (!botMember.permissions.has(PermissionFlagsBits.ManageNicknames)) {
    await message.reply({ content: "❌ Il me manque la permission **Gérer les surnoms**.", allowedMentions: { parse: [] } });
    return true;
  }

  // Hierarchy guard, before any mutation. Applying a leash also requires the actor to outrank the target;
  // releasing one (=undog) and reading it (=doginfo) only need the bot-side and owner protections.
  const hierarchy = evaluateTargetHierarchy({
    actor,
    target,
    bot: botMember,
    guildOwnerId: message.guild.ownerId,
    pndOwnerId: parsePndOwnerId(process.env.PND_OWNER_DISCORD_ID),
    enforceActorRank: command === "=dog",
    allowSelf: true, // self-target is refused earlier, except for =doginfo
  });
  if (!hierarchy.allowed) {
    await message.reply({ content: `❌ ${hierarchy.reason}`, allowedMentions: { parse: [] } });
    return true;
  }

  if (command === "=dogfix") {
    const result = await repairMemberLeash(target, message.author.tag);
    await message.reply({ content: `${result.text}${conflictWarning(result.conflicts)}`, allowedMentions: { parse: [] } });
    return true;
  }

  const records = await loadState();
  const id = key(message.guild.id, target.id);
  const existing = records[id];

  if (command === "=doginfo") {
    if (!existing) {
      await message.reply({ content: `🐾 **${target.displayName}** n'est actuellement pas en laisse.`, allowedMentions: { parse: [] } });
    } else {
      const since = Math.floor(existing.since / 1000);
      await message.reply({
        content: `🦮 **${target.user.username}** est en laisse par **${existing.ownerName}** depuis <t:${since}:R>.`,
        allowedMentions: { parse: [] },
      });
    }
    return true;
  }

  if (command === "=dog") {
    return withCommandLock(`${message.guild.id}:dog-state`, async () => {
      await pruneDepartedLeashes(message.guild);
      const result = await leashMember({ guild: message.guild, actor, author: message.author, target, guildSettings });
      await message.reply({ content: result.text, allowedMentions: { parse: [] } });
      return true;
    });
  }

  if (!existing) {
    // Leash left by the old bot (role or nickname, but nothing saved): clean it.
    if (orphanLeashParts(target).any) {
      try {
        await clearOrphanLeash(target, message.author.tag);
        await message.reply({ content: `🦴 Ancienne laisse retirée de **${target.user.username}** (rôle DOG et pseudo « 🦮 de … »).`, allowedMentions: { parse: [] } });
      } catch {
        await message.reply({ content: "❌ Impossible de retirer l'ancienne laisse : mon rôle doit être au-dessus du rôle DOG et de ce membre.", allowedMentions: { parse: [] } });
      }
      return true;
    }
    await message.reply({ content: "🐾 Ce membre n'est pas en laisse.", allowedMentions: { parse: [] } });
    return true;
  }

  // A SYS+ can release their own leash. Only the server owner / Discord
  // administrators may override another SYS+'s active leash.
  const canOverrideOwner = message.author.id === message.guild.ownerId
    || actor.permissions.has(PermissionFlagsBits.Administrator);
  if (existing.ownerId !== message.author.id && !canOverrideOwner) {
    await message.reply({
      content: "⛔ Seul le SYS+ qui a posé cette laisse peut la retirer. Le propriétaire du serveur ou un administrateur Discord peut intervenir en cas de besoin.",
      allowedMentions: { parse: [] },
    });
    return true;
  }

  return withCommandLock(`${message.guild.id}:dog-state`, async () => {
  // Re-read the record after acquiring the owner's lock to avoid racing another release.
  const current = await loadState();
  const latest = current[id];
  if (!latest || latest.releasing) {
    await message.reply({ content: "🐾 Cette laisse n'est plus active.", allowedMentions: { parse: [] } });
    return true;
  }

  try {
    // Mark release before changing the nickname so the update event won't reapply the leash.
    current[id] = { ...latest, releasing: true };
    await saveState();
    await target.setNickname(latest.previousNickname ?? null, `Laisse retirée par ${message.author.tag}`);
    if (latest.leashRoleId) {
      const role = message.guild.roles.cache.get(latest.leashRoleId)
        ?? await message.guild.roles.fetch(latest.leashRoleId).catch(() => null);
      if (role && target.roles.cache.has(role.id)) await target.roles.remove(role, `Laisse retirée par ${message.author.tag}`);
    }
    delete current[id];
    await saveState();
    await releaseLeashRoleIfUnused(message.guild, latest.leashRoleId, current).catch(() => {});
  } catch (error) {
    current[id] = latest;
    await saveState().catch(() => {});
    console.error("UNDOG command failed:", error.message);
    await message.reply({
      content: "❌ Impossible de retirer la laisse. Vérifie la hiérarchie des rôles et mes permissions.",
      allowedMentions: { parse: [] },
    });
    return true;
  }
  await sendCentralLog(message.guild, guildSettings, systemLogEmbed({ category: "dog", title: "🦴 DOG — laisse retirée", description: `Acteur : <@${message.author.id}>\nCible : <@${target.id}>` })).catch(() => {});
  await message.reply({
    content: `🦴 La laisse de **${target.user.username}** a été retirée. Son ancien surnom a été restauré.`,
    allowedMentions: { parse: [] },
  });
  return true;
  });
}

/**
 * Forget leashes of members who left this server: they no longer count in the
 * per-SYS+ quota. Only a definitive "unknown member" answer removes a record.
 */
export async function pruneDepartedLeashes(guild) {
  const records = await loadState();
  const ids = Object.values(records).filter((r) => r?.guildId === guild.id && r.memberId).map((r) => r.memberId);
  if (!ids.length) return 0;
  const present = new Set();
  try {
    for (let i = 0; i < ids.length; i += 100) {
      const found = await guild.members.fetch({ user: ids.slice(i, i + 100) });
      if (!found || typeof found.keys !== "function") return 0;
      for (const id of found.keys()) present.add(id);
    }
  } catch {
    return 0; // transient error: keep everything
  }
  let removed = 0;
  const freedRoles = new Set();
  for (const memberId of ids) {
    if (present.has(memberId)) continue;
    const roleId = records[key(guild.id, memberId)]?.leashRoleId;
    if (roleId) freedRoles.add(roleId);
    delete records[key(guild.id, memberId)];
    removed += 1;
  }
  if (removed) await saveState();
  for (const roleId of freedRoles) await releaseLeashRoleIfUnused(guild, roleId, records).catch(() => {});
  return removed;
}

export const UNDOG_ALL_DENIED = "⛔ /undogall est réservé à l'OWNER, au propriétaire du serveur et aux administrateurs.";

export function canUndogAll(member) {
  if (!member?.id || !member.guild) return false;
  if (member.id === parsePndOwnerId(process.env.PND_OWNER_DISCORD_ID) || member.id === member.guild.ownerId) return true;
  return Boolean(member.permissions?.has?.(PermissionFlagsBits.Administrator));
}

/**
 * Release leashes in bulk. scope: "serveur" (this server), "anciens" (records of
 * servers this bot is no longer on, e.g. the old bot's servers), "tout" (both).
 * Members still here get their old nickname back and lose the DOG role.
 */
export async function undogAll({ guild, client, scope = "serveur", actorTag = "bot" }) {
  const result = { released: 0, forgotten: 0, oldServers: 0, orphans: 0, failed: 0 };
  await withCommandLock(`${guild.id}:dog-state`, async () => {
    const records = await loadState();
    for (const [id, record] of Object.entries(records)) {
      if (!record?.guildId) { delete records[id]; result.oldServers += 1; continue; }
      if (record.guildId !== guild.id) {
        if ((scope === "anciens" || scope === "tout") && !client?.guilds?.cache?.has?.(record.guildId)) {
          delete records[id];
          result.oldServers += 1;
        }
        continue;
      }
      if (scope === "anciens") continue;
      const member = await guild.members.fetch({ user: record.memberId }).catch((error) => (error?.code === 10007 ? null : undefined));
      if (member === null) { delete records[id]; result.forgotten += 1; continue; }
      if (member === undefined) { result.failed += 1; continue; }
      try {
        records[id] = { ...record, releasing: true };
        await saveState();
        await member.setNickname(record.previousNickname ?? null, `Laisses retirées en masse par ${actorTag}`);
        if (record.leashRoleId && member.roles.cache.has(record.leashRoleId)) {
          await member.roles.remove(record.leashRoleId, `Laisses retirées en masse par ${actorTag}`);
        }
        delete records[id];
        result.released += 1;
        await releaseLeashRoleIfUnused(guild, record.leashRoleId, records).catch(() => {});
      } catch {
        records[id] = record;
        result.failed += 1;
      }
    }
    await saveState();
    if (scope !== "anciens") {
      // Leashes the old bot left on members (DOG role / "🦮 de …" or old "🐶 de …" nickname) with nothing saved.
      const members = await guild.members.fetch().catch(() => null);
      for (const member of members?.values?.() ?? []) {
        if (records[key(guild.id, member.id)]) continue;
        if (!orphanLeashParts(member).any) continue;
        try { if (await clearOrphanLeash(member, actorTag)) result.orphans += 1; } catch { result.failed += 1; }
      }
    }
  });
  return result;
}

export async function handleUndogAllInteraction(interaction, guildSettings = null) {
  if (!interaction.isChatInputCommand?.() || interaction.commandName !== "undogall") return false;
  if (!interaction.guild) {
    await interaction.reply({ content: "Cette commande s'utilise sur un serveur.", ephemeral: true });
    return true;
  }
  // Acknowledge Discord immediately (3-second limit), then check and work.
  await interaction.deferReply({ ephemeral: true });
  const member = interaction.member?.permissions?.has ? interaction.member : await interaction.guild.members.fetch({ user: interaction.user.id }).catch(() => null);
  if (!canUndogAll(member)) {
    await interaction.editReply({ content: UNDOG_ALL_DENIED });
    return true;
  }
  const scope = interaction.options.getString?.("portee") ?? "serveur";
  let r;
  try {
    r = await undogAll({ guild: interaction.guild, client: interaction.client, scope, actorTag: interaction.user.tag ?? interaction.user.id });
  } catch (error) {
    console.error("[dog] undogall:", error?.message ?? error);
    await interaction.editReply({ content: "❌ Le nettoyage a échoué. Vérifie que mon rôle est au-dessus du rôle DOG et des membres concernés, puis relance." }).catch(() => {});
    return true;
  }
  try { recordSysPlusAudit(interaction.guild.id, interaction.user.id, "dog.undog_all", null, { scope, ...r }); } catch { /* audit is best effort */ }
  await sendCentralLog(interaction.guild, guildSettings, systemLogEmbed({ category: "dog", title: "🦴 DOG — laisses retirées en masse", description: `Acteur : <@${interaction.user.id}>\nPortée : ${scope}\nLibérées : ${r.released} · membres partis : ${r.forgotten} · anciennes laisses : ${r.orphans} · anciens serveurs : ${r.oldServers} · échecs : ${r.failed}` })).catch(() => {});
  const lines = [
    "🦴 **Laisses DOG retirées**",
    scope !== "anciens" ? `• Sur ce serveur : **${r.released}** libérée(s), **${r.forgotten}** supprimée(s) (membres partis).` : null,
    scope !== "anciens" ? `• Anciennes laisses laissées par l'ancien bot : **${r.orphans}** retirée(s).` : null,
    scope !== "serveur" ? `• Anciens serveurs : **${r.oldServers}** laisse(s) supprimée(s).` : null,
    r.failed ? `⚠️ ${r.failed} échec(s) : vérifie que le rôle du bot est au-dessus des membres concernés, puis relance.` : null,
  ].filter(Boolean);
  await interaction.editReply({ content: lines.join("\n"), allowedMentions: { parse: [] } });
  return true;
}

// 🦮 depuis le 24/11/2026 ; 🐶 = ancien pseudo, encore reconnu pour le nettoyage.
const LEASH_NICKNAME = /^(?:🦮|🐶)\s*de\s/u;

/** A member who still shows a leash (DOG role or "🦮 de …" / old "🐶 de …" nickname) without any saved leash. */
export function orphanLeashParts(member) {
  const roles = [...(member?.roles?.cache?.values?.() ?? [])].filter((role) => isLeashRoleName(role?.name) && !role.managed);
  const nickname = LEASH_NICKNAME.test(String(member?.nickname ?? ""));
  return { roles, nickname, any: roles.length > 0 || nickname };
}

/** Remove what an old bot left behind: DOG role(s) and the leash nickname (reset to the member's own name). */
export async function clearOrphanLeash(member, actorTag = "bot") {
  const { roles, nickname, any } = orphanLeashParts(member);
  if (!any) return false;
  for (const role of roles) await member.roles.remove(role, `Ancienne laisse DOG retirée par ${actorTag}`);
  if (nickname) await member.setNickname(null, `Ancienne laisse DOG retirée par ${actorTag}`);
  return true;
}
